<?php

if(isset(['login'])) {
    $a = mysqli_connect("localhost", "root", "") or die("connection failed");

    echo "<br>";
    $b = mysqli_select_db($a, "college") or die("connection faileddddddd");
    $c = $_POST['username'];
    $d = $_POST['remb'];
    $e = $_POST['csss'];

    $f = "insert into studentinfo values($c,'$d','$e')";
    mysqli_query($a, $f);

    echo "1 record is inserted";
}

?>


<html>
<body>
<form name="f1" action="cnct.php" method="POST">
  roll no:<input type="text" name="username">
    name:<input type="text" name="remb">
    class:<input type="text",name="csss">
    <input type="submit" name="login">
</form>
</body>
</html>