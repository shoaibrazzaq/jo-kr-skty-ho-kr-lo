<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Join Pak Army</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body id="home">
<nav class="navbar navbar-expand-md navbar-light">
    <div class="container">
        <a href="index.php" class="navbar-brand">
            <img src="img/army-logo" width="50" height="50" alt=""><h3 class="d-inline align-middle"> Join Pak Army </h3>
        </a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="#showcase" class="nav-link">Candidates</a>
                </li>
                <li class="nav-item">
                    <a href="#join" class="nav-link">Join</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<!-- JOIN -->
<section id="join" class="bg-light py-4">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12 col-lg-9">
                <h3>Filter Eligible Candidates </h3>
                <p class="lead">JOIN PAK ARMY AS CAPTAIN THROUGH DIRECT SHORT SERVICE COMMISSION</p>
                <!--Question 1: Part 01:  Write the code below accordingly-->
                <form method="GET" action="#">
                    <div class="form-row">
                        <div class="col-md-12">
                            <textarea name="data" class="form-control"
                                      placeholder="Copy students data from 'data.txt' file and paste here to filter ..."
                                      id="data" rows="16"></textarea>
                        </div>
                    </div>
                    <input type="submit" value="Filter" id="filter" name="filter" class="btn btn-dark btn-block btn-lg">
                </form>
            </div>
            <div class="col-lg-3 d-none d-lg-block align-self-center">
                <img src="img/army.png" alt="Army" class="img-fluid">
            </div>
        </div>
    </div>
</section>
<section id="showcase" class="py-5">
    <div class="primary-overlay text-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 text-center offset-lg-1">
                    <h4 class="display-4 mt-5">
                        Eligible Candidates List
                    </h4>
                    <p class="lead"></p>
                    <table class="table table-hover table-sm">
                        <thead>
                        <tr>
                            <td> Name </td>
                            <td> Reg# </td>
                            <td> CGPA </td>
                            <td> Dob </td>
                            <td> Height </td>
                            <td> Actions </td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php

                            if (isset($_REQUEST['filter']) && isset($_REQUEST['data']))
                            {
                                $regex = "/\d+\s+([A-Z]+((\.\s|\s|-|\.)?[A-Z]+)*)\s+(L\d[FS]\d{2}BSCS\d{4})\s+([\w.]*)\s+([\d\/]*)\s+([\d\^\d\d?]+)/m";
                                $result;
                                $count = preg_match_all($regex, $_REQUEST['data'], $result);
                                echo count($result[0])."<br>";
                                for($i = 0; $i < $count; $i++)
                                {
                                    $reg1 = "/\s+((2\.5[1-9]|2\.[6-9]\d?)|[3](\.\d\d?)?|4(\.0)?)\s+((0?\d|[1-2][0-9]|3[01])\/(0?\d|1[0-2])\/19(89|9[0-9]))\s+(5\^(0?[3-9]|[1][0-2])|6(\^(0?\d|[1][0-2]))?|7([^\^]|\^0))/";
                                    $res1;
                                    preg_match_all($reg1, $result[0][$i], $res1);
                                    if (count($res1[0]) > 0)
                                    {
                                        $name = $result[1][$i];
                                        $regno = $result[4][$i];
                                        $cgpa = $res1[1][0];
                                        $date = $res1[5][0];
                                        $height = $res1[9][0];
                                        $click = "apply('$name', '$regno', '$cgpa', '$date', '$height');";
                                        echo "<tr>
                                                <td>$name</td>
                                                <td>$regno</td>
                                                <td>$cgpa</td>
                                                <td>$date</td>
                                                <td>$height</td>
                                                <td><button class='btn btn-dark' id = '$regno' onclick=\"".$click."\">action</button></td>
                                            </tr>";
                                    }
                                }
                            }

                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<footer id="main-footer" class="py-3 bg-primary text-white">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-6 ml-auto">
                <p class="lead">Copyright &copy; 2019</p>
            </div>
        </div>
    </div>
</footer>
<script>
    /*Question 2:  Write the code below accordingly*/
    function apply(name, reg, cgpa, date, height){
        var obj = new XMLHttpRequest();
        obj.onreadystatechange = function(){
            if (this.readyState == 4 && this.status==200)
            {
                document.getElementById(reg).innerText = this.responseText;
                document.getElementById(reg).classList.remove("btn-dark");
                document.getElementById(reg).classList.add("btn-warning");
            }
        };
        var url = "apply.php?name="+name+"&reg="+reg+"&cgpa="+cgpa+"&date="+date+"&height="+height;
        obj.open("GET", url, true);
        obj.send();
    }
</script>
</body>
</html>