 <html>
 <body>
 <form name="f1">
     NAME:<input type="text" value="REHMAT ALI"readonly>
     <br>
     PHONE NUMBER:<input type="text" value="03477111268"readonly>
     <br>
     EMAIL:<input type="text" value="rehmat.ali@ucp.edu.pk" readonly>
     <br>
 </form>
 </body>
 </html>
