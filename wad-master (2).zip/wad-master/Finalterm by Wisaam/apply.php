<?php
$connection = mysqli_connect('localhost','root','','army_db');
if(!$connection)
    die("'army_db' database not connected.");
/* Question 2:  Write the code below accordingly */

if (isset($_REQUEST['name']) && isset($_REQUEST['reg']) && isset($_REQUEST['cgpa']) && isset($_REQUEST['date']) && isset($_REQUEST['height']))
{
	$name = $_REQUEST['name'];
	$reg = $_REQUEST['reg'];
	$cgpa = $_REQUEST['cgpa'];
	$date = $_REQUEST['date'];
	$height = $_REQUEST['height'];

	$sql = "SELECT * FROM candidates WHERE reg = '$reg';";
	$res = mysqli_query($connection, $sql);
	if (mysqli_num_rows($res) > 0)
	{
		echo "Cannot Apply Twice";
		die();
	}
	else
	{
		$sql = "INSERT INTO candidates (name, reg, cgpa, dob, height) VALUES ('$name', '$reg', '$cgpa', '$date', '$height');";
		$res = mysqli_query($connection, $sql);
		if ($res)
			echo "Applied Successfully";
	}
}
